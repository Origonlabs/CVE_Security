"""
Example plugins for repo-scan.
"""
