"""REST API package for repo-scan."""

from .server import create_app

__all__ = ["create_app"]
