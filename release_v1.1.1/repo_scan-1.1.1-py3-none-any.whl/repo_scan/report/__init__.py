"""
Report generation module for repo-scan.
"""

from .generator import ReportGenerator

__all__ = ["ReportGenerator"]
